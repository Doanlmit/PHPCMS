CodeIgniter - Nested Sets Library
==============

Improved / Fixed Nested Set Library for CodeIgniter, originally created by Thunder / intel352
